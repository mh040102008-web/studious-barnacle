package com.example.devicecare

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 17, 31)
    private val card = Color.rgb(15, 31, 51)
    private val blue = Color.rgb(58, 146, 255)
    private val green = Color.rgb(41, 217, 163)
    private val white = Color.rgb(238, 245, 255)
    private val muted = Color.rgb(151, 171, 195)
    private lateinit var content: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildHome()
    }

    private fun buildHome() {
        val pad = dp(18)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(pad, dp(12), pad, pad)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        val brand = TextView(this).apply {
            text = "DEVICECARE"
            textSize = 13f
            letterSpacing = 0.18f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(brand)
        root.addView(TextView(this).apply {
            text = "خلّيك مطمئن على جهازك"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(7), 0, dp(5))
        })
        root.addView(TextView(this).apply {
            text = "فحص سريع لمعلومات الهاتف وأدائه"
            textSize = 14f; setTextColor(muted)
        })
        summary = TextView(this).apply {
            textSize = 15f
            setTextColor(white)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(card, 18)
        }
        val summaryParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        root.addView(summary, summaryParams)
        root.addView(section("أدوات الجهاز"))
        root.addView(actionCard("🔋", "فحص صحة الجهاز", "البطارية، الحرارة، الذاكرة والتخزين") { showHealth() })
        root.addView(actionCard("📳", "اختبار الاهتزاز", "اختبر محرك الاهتزاز في هاتفك") { vibrateTest() })
        root.addView(actionCard("🧹", "مسح الملفات المؤقتة", "يمسح ملفات الكاش الخاصة بهذا التطبيق فقط") { clearCacheConfirm() })
        root.addView(actionCard("⚙️", "إعدادات الجهاز", "افتح إعدادات النظام لإدارة الجهاز") { openSettings() })
        root.addView(TextView(this).apply {
            text = "ملاحظة: لا يستطيع التطبيق فحص كل أعطال الهاتف أو إعادة ضبط المصنع مباشرةً. لا تُحذف أي بيانات شخصية."
            textSize = 12f; setTextColor(muted); setPadding(dp(4), dp(16), dp(4), dp(12))
        })
        setContentView(scroll)
        updateSummary()
    }

    private fun section(s: String): TextView = TextView(this).apply {
        text = s; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
        setPadding(0, dp(22), 0, dp(8))
    }

    private fun actionCard(icon: String, title: String, detail: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(card, 16)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val glyph = TextView(this).apply {
            text = icon; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(green)
        }
        box.addView(glyph, LinearLayout.LayoutParams(dp(46), dp(46)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        texts.addView(TextView(this).apply {
            text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
        })
        texts.addView(TextView(this).apply {
            text = detail; textSize = 12f; setTextColor(muted); setPadding(0, dp(4), 0, 0)
        })
        box.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        return box.also { it.layoutParams = lp }
    }

    private fun updateSummary() {
        val battery = batteryInfo()
        val stat = StatFs(Environment.getDataDirectory().path)
        val free = stat.availableBytes
        val total = stat.totalBytes
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        summary.text = "نظرة سريعة\n\n" +
            "🔋 البطارية: ${battery.level?.let { "$it%" } ?: "غير متاحة"}\n" +
            "💾 التخزين المتاح: ${gb(free)} GB من ${gb(total)} GB\n" +
            "🧠 الذاكرة المتاحة تقريباً: ${gb(mem.availMem)} GB\n" +
            "📱 أندرويد ${Build.VERSION.RELEASE}"
    }

    private data class BatteryInfo(val level: Int?, val temp: Double?, val health: String)

    private fun batteryInfo(): BatteryInfo {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (intent == null) return BatteryInfo(null, null, "غير معروفة")
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val health = when (intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "حرارة مرتفعة"
            BatteryManager.BATTERY_HEALTH_DEAD -> "تحتاج فحصاً"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد"
            BatteryManager.BATTERY_HEALTH_COLD -> "باردة"
            else -> "غير معروفة"
        }
        return BatteryInfo(if (level >= 0) level * 100 / scale else null,
            if (tempRaw >= 0) tempRaw / 10.0 else null, health)
    }

    private fun showHealth() {
        val sb = StringBuilder()
        sb.appendLine("تقرير فحص الجهاز")
        sb.appendLine("الجهاز: ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("أندرويد: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        val b = batteryInfo()
        sb.appendLine("البطارية: ${b.level?.let { "$it%" } ?: "غير متاحة"}")
        sb.appendLine("حرارة البطارية: ${b.temp?.let { "$it °C" } ?: "غير متاحة"}")
        sb.appendLine("حالة البطارية: ${b.health}")
        val stat = StatFs(Environment.getDataDirectory().path)
        sb.appendLine("التخزين المتاح: ${gb(stat.availableBytes)} GB من ${gb(stat.totalBytes)} GB")
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        sb.appendLine("الذاكرة المتاحة تقريباً: ${gb(mi.availMem)} GB من ${gb(mi.totalMem)} GB")
        if (mi.lowMemory) sb.appendLine("تنبيه: النظام يبلّغ عن انخفاض الذاكرة.")
        val sensors = (getSystemService(SENSOR_SERVICE) as SensorManager).getSensorList(Sensor.TYPE_ALL).size
        sb.appendLine("عدد أنواع الحساسات: $sensors")
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps == null -> "لا يوجد اتصال نشط"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "بيانات الجوال"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "متصل"
        }
        sb.appendLine("الشبكة: $net")
        val pm = packageManager
        sb.appendLine("كاميرا: ${yn(pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY))}")
        sb.appendLine("GPS: ${yn(pm.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS))}")
        sb.appendLine("بلوتوث: ${yn(pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH))}")
        AlertDialog.Builder(this)
            .setTitle("فحص صحة الجهاز")
            .setMessage(sb.toString())
            .setPositiveButton("تحديث") { _, _ -> updateSummary(); showHealth() }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun vibrateTest() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (!vibrator.hasVibrator()) { toast("هذا الجهاز لا يحتوي على محرك اهتزاز"); return }
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(350)
        }
        toast("هل شعرت بالاهتزاز؟")
    }

    private fun clearCacheConfirm() {
        AlertDialog.Builder(this)
            .setTitle("مسح الملفات المؤقتة")
            .setMessage("سيتم مسح الملفات المؤقتة الخاصة بتطبيق DeviceCare فقط. لن تُمسح الصور أو الملفات الشخصية.")
            .setPositiveButton("مسح") { _, _ ->
                val ok = runCatching { cacheDir.listFiles()?.forEach { it.deleteRecursively() }; true }.getOrDefault(false)
                toast(if (ok) "تم مسح الملفات المؤقتة للتطبيق" else "تعذر مسح بعض الملفات")
                updateSummary()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun openSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            .onFailure { toast("تعذر فتح الإعدادات") }
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun gb(bytes: Long) = String.format(Locale.US, "%.1f", bytes / 1_073_741_824.0)
    private fun yn(v: Boolean) = if (v) "متوفر" else "غير متوفر"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
